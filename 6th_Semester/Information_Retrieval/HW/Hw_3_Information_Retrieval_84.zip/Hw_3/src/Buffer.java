import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Buffer {
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("enter an integer: ");
        int a = Integer.parseInt(br.readLine());

        System.out.print("enetr a string: ");
        String s = br.readLine();

        System.out.println("you entered "+ a + " and "+s);
    }
}
