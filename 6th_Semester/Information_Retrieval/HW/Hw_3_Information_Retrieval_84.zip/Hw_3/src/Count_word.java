import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Count_word {
    public static void main(String[] args) {
        String[] words=null;
        File dir = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory");
        dir.mkdir();
        File word_file = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list.txt");
        /*File word_file_first = new File("H:/Java_Language/Information_retrieval/Hw_3/src/Word_list.txt");*/
        int count = 0;
        try{
            word_file.createNewFile();
            System.out.println("the file word_list.txt has been created properly ");
            FileReader readfile = new FileReader(word_file);
            BufferedReader in = new BufferedReader(readfile);
            String s ;

            while((s=in.readLine())!=null){
                words = s.split(" ");
                count =count+ words.length;
            }
            readfile.close();

        }catch(Exception e){
            System.out.println("problem when creating a file for word_list.txt");
        }
       /* word_file_first.delete();*/
        System.out.println("there is "+count+" words in the file");

    }
}
