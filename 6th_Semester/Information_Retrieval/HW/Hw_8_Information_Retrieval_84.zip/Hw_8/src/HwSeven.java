import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class HwSeven {
    public static void main(String[] args) {
        try {
            File file = new File("E:/CQUT/Information_retrieval/Hw_8/word_directory/Word_list.txt");
            Scanner sc = new Scanner(file);
            int cnt = 0;
            int rpd = 0;
            String[] a = new String[1300];//1300
            String[] rpdword = new String[1300]; //1300
            while (sc.hasNext()) {
                String s = sc.next();
                if (cnt < a.length) //1300
                    a[cnt] = s;
                cnt++;
            }
            sc.close();

            System.out.println("There are " + cnt + " words there.");

            System.out.println();

            for(int b = 0; b<1128; b++){ //1248
                rpd = 0;
                for(int c=b; c<=1129; c++){ //1249
                    if(a[b].equals(a[c])){
                        rpd++;
                        if(rpd>4){
                            rpdword[b] =a[c];

                        }
                    }
                }
            }
            System.out.println("the repeaded word more than 4 times is ");

            for(int x =0; x<=rpdword.length-2; x++){
                if(rpdword[x]==null){
                    rpdword[x] = rpdword[x+1];
                }
            }

            //duplicates

            List<String> listWithoutDuplicates = Arrays.asList(rpdword).stream().distinct().collect(Collectors.toList());

            System.out.println(" "+listWithoutDuplicates);

        } catch (FileNotFoundException e) {
        }
    }
}