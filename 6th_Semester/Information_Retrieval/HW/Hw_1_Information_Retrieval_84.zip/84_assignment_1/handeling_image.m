clear;
clc;

%%%%%%%%%%%% Reading Images %%%%%%%%%%%%%%

Coliseum = imread('C:\84_assignment_1\file\images\image.PNG');
image(Coliseum);

%%%%%%%%%%%%%%%  wrte images %%%%%%%%%%%%%%%%%
imwrite(Coliseum,'C:\84_assignment_1\file\images\image.PNG');
