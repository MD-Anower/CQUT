clear;
clc;


% audiowrite('C:\84_assignment_1\file\audio\a13_001.wav',y,Fs);
filename = audioread('C:\84_assignment_1\file\audio\a13_001.wav');
[audio_data,Fs] = audioread('C:\84_assignment_1\file\audio\a13_001.wav');

sound(audio_data,Fs);

plot(audio_data);