clear;
clc;
delete('C:\84_assignment_1\file\write_to_file\MyMatrix.txt');
delete('C:\84_assignment_1\file\write_to_file\MyMatrix.xls');
delete('C:\84_assignment_1\file\write_to_file\MyMatrix.csv');
%%%%%%%%%%%%%%% Exporting data from MATLAB %%%%%%%%%%%%%%%%%%

MyMatrix = rand(7);

disp('code 16 in chapter 2');
disp(MyMatrix);

% Now simply write a matrix named MyMatrix to a file named MyMatrix.txt using the default delimiter (,)

dlmwrite('C:\84_assignment_1\file\write_to_file\MyMatrix.txt', MyMatrix);

disp('result from exported txt file');
type('C:\84_assignment_1\file\write_to_file\MyMatrix.txt');

xlswrite('C:\84_assignment_1\file\write_to_file\MyMatrix.xls', MyMatrix);

csvwrite('C:\84_assignment_1\file\write_to_file\MyMatrix.csv', MyMatrix);

