import java.io.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Count_word {
    public static void main(String[] args) {
        String[] words=null;
        File dir = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory");
        dir.mkdir();
        File word_file1 = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list1.txt");
        File word_file2 = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list2.txt");
        File word_file3 = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list3.txt");
        File word_file4 = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list4.txt");
        File word_file5 = new File("H:/Java_Language/Information_retrieval/Hw_3/word_directory/Word_list5.txt");


        int count = 0;
        try{
            word_file1.createNewFile();
            word_file2.createNewFile();
            word_file3.createNewFile();
            word_file4.createNewFile();
            word_file5.createNewFile();


            System.out.println("the file word_list1-5.txt has been created properly ");
            FileReader readfile1 = new FileReader(word_file1);
            FileReader readfile2 = new FileReader(word_file2);
            FileReader readfile3 = new FileReader(word_file3);
            FileReader readfile4 = new FileReader(word_file4);
            FileReader readfile5 = new FileReader(word_file5);

            BufferedReader in1 = new BufferedReader(readfile1);
            BufferedReader in2 = new BufferedReader(readfile1);
            BufferedReader in3 = new BufferedReader(readfile1);
            BufferedReader in4 = new BufferedReader(readfile1);
            BufferedReader in5 = new BufferedReader(readfile1);
            String s ;

            while((s=in1.readLine())!=null){

                words = s.split(" ");
                count =count+ words.length;
            }
            readfile1.close();
            readfile2.close();
            readfile3.close();
            readfile4.close();
            readfile5.close();

        }catch(Exception e){
            System.out.println("problem when creating a file for word_list.txt");
        }
       /* word_file_first.delete();*/
        System.out.println("there is "+count+" words in the file");

    }
}
