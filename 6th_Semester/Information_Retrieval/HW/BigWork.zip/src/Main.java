public class Main {

    public static void main(String[] args) {
        BigCLass bc = new BigCLass();

        bc.ReadBigFile();
        bc.MakeDirAnd10FIle();
        bc.WriteToFile();
        bc.Reading10DocFile();

    }
}