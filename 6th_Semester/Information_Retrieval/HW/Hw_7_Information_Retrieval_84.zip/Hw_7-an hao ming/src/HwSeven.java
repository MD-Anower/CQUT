import java.io.*;
import java.util.Scanner;

public class HwSeven {
    public static void main(String[] args) {
        try {
            File file = new File("E:/CQUT/Information_retrieval/Hw_7/word_directory/Word_list.txt");
            Scanner sc = new Scanner(file);
            int cnt = 0;
            String[] a = new String[20];
            while (sc.hasNext()) {
                String s = sc.next();
                if (cnt < 20) a[cnt] = s;
                cnt++;
            }
            sc.close();

            System.out.println("There are " + cnt + " words there.");
            System.out.print("the number in descending order is ");
            for(int i = cnt; i>=1; i--){
                if(i%30==0)
                    System.out.println();
                System.out.print(" "+i);
            }
            System.out.println();
            System.out.print("and first 20 words is: ");
            for (String tmp : a) if (tmp != null)
                System.out.print(" "+tmp);
        } catch (FileNotFoundException e) {
        }
    }
}