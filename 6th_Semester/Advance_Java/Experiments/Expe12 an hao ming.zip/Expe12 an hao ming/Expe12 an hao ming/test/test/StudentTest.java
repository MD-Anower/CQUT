package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

import entity.Student;

public class StudentTest {

	@Test
	public void insertTest(){
		System.out.println("insertTest start...");
		try
		{
			//1.loadConfigurationfile
			Configuration config = new Configuration().configure();
			//2.getSessionFactory
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
			SessionFactory sessionFactory = config.buildSessionFactory(serviceRegistry);
			//3.get a session
			Session session = sessionFactory.openSession();
			//4.begin transaction
			Transaction t = session.beginTransaction();
			//5.create data object
			Student s = new Student();
			s.setNo("1002");
			s.setName("Kim");
			s.setAge(20);
			s.setGender("male");
			//6.save data
			session.save(s);
			t.commit();
			//7.close resource
			session.close();
			sessionFactory.close();
			}
			catch(Exception ex){
				System.out.println(ex);
		}
		System.out.println("insertTest end...");
	}
	@Test
	public void updateTest(){
		System.out.println("updateTest start...");
		try
		{
			//1.loadConfigurationfile
			Configuration config = new Configuration().configure();
			//2.getSessionFactory
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
			SessionFactory sessionFactory = config.buildSessionFactory(serviceRegistry);
			//3.get a session
			Session session = sessionFactory.openSession();
			//4.begin transaction
			Transaction t = session.beginTransaction();
			//5.create data object
			Student s = new Student();
			s.setId(3);
			s.setNo("1002");
			s.setName("kim");
			s.setAge(21);
			s.setGender("female");
			//6. update the student and commit the transaction
			session.update(s);
			t.commit();
			//7. closer resource
			session.close();
			sessionFactory.close();
			}
			catch(Exception ex){
				System.out.println(ex);
		}
		System.out.println("updateTest end...");
	}
	@Test
	public void findByIdTest(){
		System.out.println("findByIdTest start...");
		Transaction t = null;
		try
		{
			//1.loadConfigurationfile
			Configuration config = new Configuration().configure();
			//2.getSessionFactory
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
			SessionFactory sessionFactory = config.buildSessionFactory(serviceRegistry);
			//3.get a session
			Session session = sessionFactory.openSession();
			//4.begin transaction
			 t = session.beginTransaction();
			//5. get data by using get() or load()
			int id = 3;
			Student s = (Student)session.get(Student.class,id);
			
			System.out.println("No" + s.getNo());
			System.out.println("Name" + s.getName());
			System.out.println("Age" + s.getAge());
			System.out.println("Gender" + s.getGender());
			
			//6. commit the transaction
			t.commit(); 
			
			//7. closer resource
			session.close();
			sessionFactory.close();
			}
			catch(Exception ex){
				System.out.println(ex);
				t.rollback();
		}
		System.out.println("findByIdTest end...");
	}
	
}
