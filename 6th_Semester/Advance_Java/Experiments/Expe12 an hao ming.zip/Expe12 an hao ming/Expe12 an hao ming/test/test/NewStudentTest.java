package test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import entity.Student;

public class NewStudentTest {
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction t;
	@Before
	public void init(){
		//1.loadConfigurationfile
		Configuration config = new Configuration().configure();
		//2.getSessionFactory
		ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
		SessionFactory sessionFactory = config.buildSessionFactory(serviceRegistry);
		//3.get a session
		Session session = sessionFactory.openSession();
		//4.begin transaction
		Transaction t = session.beginTransaction();
	}
	@After
	public void destory(){
		//6. commit the transaction
		t.commit(); 
		
		//7. closer resource
		session.close();
		sessionFactory.close();
	}
	
	@Test
	public void insertTest(){
		//5.create data object
		Student s = new Student();
		s.setNo("1003");
		s.setName("Jim");
		s.setAge(19);
		s.setGender("male");
		//6.save data
		session.save(s);
	}
	@Test
	public void updateTest(){
		//5.create data object
		Student s = new Student();
		s.setId(3);
		s.setNo("1002");
		s.setName("Jim");
		s.setAge(20);
		s.setGender("female");
		//6. update the student and commit the transaction
		session.update(s);
	}
	@Test
	public void findByIdTest(){
		//5. get data by using get() or load()
		int id = 4;
		Student s = (Student)session.get(Student.class,id);
		
		System.out.println("No" + s.getNo());
		System.out.println("Name" + s.getName());
		System.out.println("Age" + s.getAge());
		System.out.println("Gender" + s.getGender());
	}
	@Test
	public void deleteByIdTest(){
		//5. get data by using get() or load()
		int id = 1;
		Student s = (Student)session.get(Student.class,id);
		session.delete(s);
	}
	@Test
	public void findAllIdTest(){
		String hql = "from student";
		Query query = session.createQuery(hql);
		List<Student> list = query.list();
		
		for(Student s : list){
			System.out.println("----------------------------");
			//System.out.println(s)
			System.out.println("Id" + s.getId());
			System.out.println("No" + s.getNo());
			System.out.println("Name" + s.getName());
			System.out.println("Age" + s.getAge());
			System.out.println("Gender" + s.getGender());
			System.out.println("----------------------------");
		}
	}
}
