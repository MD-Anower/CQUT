package dao;

public class UserDao {
	public void save(){
		System.out.println("Spring: Hello userDao!");
	}
}
