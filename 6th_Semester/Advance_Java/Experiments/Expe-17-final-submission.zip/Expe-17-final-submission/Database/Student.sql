/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [Id]
      ,[No]
      ,[Name]
      ,[Age]
      ,[Gender]
  FROM [LibraryNewDB].[dbo].[Student]