package action;

import model.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class loginAction2 extends ActionSupport implements ModelDriven<User>{

	private User user = new User();

	@Override
	public User getModel() {
		return user;
	}
	
	@Override
	public String execute() throws Exception {
		
		ActionContext context = ActionContext.getContext();
		if(user.getUserName().equals("hangaofu") && user.getPassword().equals("1234")){
			context.put("UserName", user.getUserName());
			context.put("password", user.getPassword());
			context.put("success", "login success");
			
			return "success";
		}
		else{
			context.put("error", "login error");
			
			return "error";
		}
	}

}
