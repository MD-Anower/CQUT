package action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import model.User;

public class loginAction extends ActionSupport {

	private User user;
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String execute() throws Exception {

		ActionContext context = ActionContext.getContext();
		if(user.getUserName().equals("hangaofu") && user.getPassword().equals("1234")){
			context.put("UserName", user.getUserName());
			context.put("password", user.getPassword());
			context.put("success", "login success");
			
			return "success";
		}
		else{
			context.put("error", "login error");
			
			return "error";
		}
	}

}
