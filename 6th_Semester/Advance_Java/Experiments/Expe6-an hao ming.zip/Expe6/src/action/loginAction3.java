package action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class loginAction3 extends ActionSupport {

	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String execute() throws Exception {
		HttpServletRequest request = ServletActionContext.getRequest();
		
		if(userName.equals("hangaofu") && password.equals("1234")){
			request.setAttribute("UserName", userName);
			request.setAttribute("password", password);
			request.setAttribute("success", "login success");
			
			return "success";
		}
		else{
			request.setAttribute("error", "login error");
			
			return "error";
		}
		
	}

}
