package action;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class loginAction extends ActionSupport {

	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String execute() throws Exception {
		
		ActionContext context = ActionContext.getContext();
		if(userName.equals("hangaofu") && password.equals("1234")){
			context.put("UserName", userName);
			context.put("password", password);
			context.put("success", "login success");
			
			return "success";
		}
		else{
			context.put("error", "login error");
			
			return "error";
		}
	}
	
}
