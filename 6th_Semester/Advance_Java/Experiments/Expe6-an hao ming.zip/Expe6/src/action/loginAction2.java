package action;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionSupport;

public class loginAction2 extends ActionSupport implements ServletRequestAware {
	
	private String userName;
	private String password;
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	HttpServletRequest request;
	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		this.request = request;
	}
	@Override
	public String execute() throws Exception {
		if(userName.equals("hangaofu") && password.equals("1234")){
			request.setAttribute("UserName", userName);
			request.setAttribute("password", password);
			request.setAttribute("success", "login success");
			
			return "success";
		}
		else{
			request.setAttribute("error", "login error");
			
			return "error";
		}
	}

	
}
