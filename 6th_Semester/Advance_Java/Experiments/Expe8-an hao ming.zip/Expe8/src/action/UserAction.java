package action;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}
   public String add(){
	   return "add";
   }
}
