package action;

import com.opensymphony.xwork2.ActionSupport;

public class BookAction extends ActionSupport {

	@Override
	public String execute() throws Exception {
		
		return "success";
	}
	public String add(){
		System.out.println("Add Book");
		return SUCCESS;
	}
	public String del(){
		System.out.println("Book Delete");
		return SUCCESS;
	}
	public String update(){
		System.out.println("Book update");
		return SUCCESS;
	}
	public String find(){
		System.out.println("find Book");
		return SUCCESS;
	}

}
