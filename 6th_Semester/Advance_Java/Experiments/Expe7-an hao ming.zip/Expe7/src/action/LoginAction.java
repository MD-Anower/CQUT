package action;

import model.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class LoginAction extends ActionSupport implements ModelDriven <User>{
	private User user = new User();
	@Override
	public User getModel() {
		// TODO Auto-generated method stub
		return user;
	}
	
	@Override
	public String execute() throws Exception {
		ActionContext actionContext = ActionContext.getContext();
		
		if(user.getUserName().equals("admin") && user.getPassWord().equals("123")){
			actionContext.getSession().put("user", user);
			return "SUCCESS";
		}else {
			actionContext.put("msg","User name Or passWord is wrong");
			return "input";
		}

	}
}