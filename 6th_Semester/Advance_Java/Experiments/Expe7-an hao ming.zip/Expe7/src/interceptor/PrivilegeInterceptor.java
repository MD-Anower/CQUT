package interceptor;

import model.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class PrivilegeInterceptor extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		ActionContext actionContext = invocation.getInvocationContext();
		User user = (User)actionContext.getSession().get("user");
		if(user !=null){
			return invocation.invoke();
		}
		else actionContext.put("msg","please log in");
		return "login";
	}

}
