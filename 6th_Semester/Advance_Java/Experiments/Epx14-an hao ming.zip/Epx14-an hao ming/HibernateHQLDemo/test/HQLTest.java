import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import entity.Student;


public class HQLTest {
	@Test
	public void aliasTest(){
		System.out.println("aliasTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = " from Student as s where s.Name='kim'";
		Query query = session.createQuery(hql);
		
		List<Student> list = query.list();
		for(Student s: list){
			System.out.println("-----------------------");
			//System.out.println(s);
			//System.out.println("Id:"+ s.getId());
			//System.out.println("No:"+ s.getNo());
			//System.out.println("Name:"+ s.getName());
			//System.out.println("Age:"+ s.getAge());
			//System.out.println("Gender:"+ s.getGender());
			System.out.println(s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("aliasTest end.....");		

}
	@Test
	public void projectionQueryTest(){
		System.out.println("projectionQueryTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = " select s.No, s.Name from Student as s";
		Query query = session.createQuery(hql);
		
		List<Object[]> list = query.list();
		for(Object[] s: list){
			System.out.println("-----------------------");
			
			System.out.println("No:"+ s[0]);
			System.out.println("Name:"+ s[1]);
		
			System.out.println(s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("projectionQueryTest end.....");		
	}
	@Test
	public void dynamicQueryTest(){
		System.out.println("dynamicQueryTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = " select new Student(s.No, s.Name) from Student as s";
		Query query = session.createQuery(hql);
		
		List<Student> list = query.list();
		for(Student s: list){
			System.out.println("-----------------------");
			
			System.out.println("No:"+ s.getNo());
			System.out.println("Name:"+ s.getName());
		
			System.out.println(s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("dynamicQueryTest end.....");		
	}
	@Test
	public void parameterByPositionQueryTest(){
		System.out.println("parameterByPositionQueryTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = "  from Student as s where s.Name=? and s.No=?";
		Query query = session.createQuery(hql);
		query.setString(0, "Amin");
		query.setString(1, "1005");
		
		List<Student> list = query.list();
		for(Student s: list){
			System.out.println("-----------------------");
			System.out.println("Student:"+ s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("parameterByPositionQueryTest end.....");		
	}
	@Test
	public void parameterByNameQueryTest(){
		System.out.println("parameterByNameQueryTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = "  from Student as s where s.Name=:name and s.No=:no";
		Query query = session.createQuery(hql);
		query.setParameter("name", "ruma");
		query.setParameter("no", "1004");
		
		List<Student> list = query.list();
		for(Student s: list){
			System.out.println("-----------------------");
			System.out.println("Student:"+ s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("parameterByNameQueryTest end.....");		
	}
	@Test
	public void pagingQueryTest(){
		System.out.println("pagingQueryTest start.....");
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		String hql = "  from Student ";
		Query query = session.createQuery(hql);
		
		query.setFirstResult(1);
		query.setFirstResult(2);
		
		List<Student> list = query.list();
		for(Student s: list){
			System.out.println("-----------------------");
			System.out.println("Student:"+ s.toString());
			System.out.println("-----------------------");
		}
		t.commit();
		HibernateSessionFactory.closeSession();
		System.out.println("pagingQueryTest end.....");		
	}
	
	
}