package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;
import org.junit.Test;

import entity.Student;

public class StudentTest {

	@Test
	public void insertTest(){
		System.out.println("insertTest start...");
		try
		{
			//1.loadConfigurationfile
			Configuration config = new Configuration().configure();
			//2.getSessionFactory
			ServiceRegistry serviceRegistry = new ServiceRegistryBuilder().applySettings(config.getProperties()).buildServiceRegistry();
			SessionFactory sessionFactory = config.buildSessionFactory(serviceRegistry);
			//3.get a session
			Session session = sessionFactory.openSession();
			//4.begin transaction
			Transaction t = session.beginTransaction();
			//5.create data object
			Student s = new Student();
			s.setNo("1002");
			s.setName("Kim");
			s.setAge(20);
			s.setGender("male");
			//6.save data
			session.save(s);
			t.commit();
			//7.close resource
			session.close();
			sessionFactory.close();
			}
			catch(Exception ex){
				System.out.println(ex);
		}
		System.out.println("insertTest end...");
	}
}
