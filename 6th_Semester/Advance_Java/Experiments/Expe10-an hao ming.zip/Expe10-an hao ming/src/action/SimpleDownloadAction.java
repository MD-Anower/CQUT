package action;

import java.io.InputStream;

import javax.servlet.ServletContext;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class SimpleDownloadAction extends ActionSupport {

	public InputStream getDownloadFile(){
		ServletContext sc = ServletActionContext.getServletContext();
		return sc.getResourceAsStream("/upload/Expe2 JSTL.doc");
	}
	@Override
	public String execute() throws Exception {
		
		return SUCCESS;
	}

}
