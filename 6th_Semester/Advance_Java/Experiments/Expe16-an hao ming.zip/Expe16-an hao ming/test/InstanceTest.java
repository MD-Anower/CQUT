import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class InstanceTest {
	@Test
	public void demo1(){
		String xmlPath = "applicationContext.xml";
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(xmlPath);
		
		System.out.println(applicationContext.getBean("bean1"));
	}
	
	@Test
	public void demo2(){
		String xmlPath = "applicationContext.xml";
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(xmlPath);
		
		System.out.println(applicationContext.getBean("bean2"));
	}
	
	@Test
	public void demo3(){
		String xmlPath = "applicationContext.xml";
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(xmlPath);
		
		System.out.println(applicationContext.getBean("bean3"));
	}
	
	@Test
	public void hello(){
		String xmlPath = "applicationContext.xml";
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext(xmlPath);
		
		System.out.println(applicationContext.getBean("hello"));
		System.out.println(applicationContext.getBean("hello"));
		System.out.println(applicationContext.getBean("hello"));
	}
}

