package factory;

import bean.Bean1;

public class MyBean3Factory {
	public  Bean1 createBean(){
		return new Bean1();
	}
}
