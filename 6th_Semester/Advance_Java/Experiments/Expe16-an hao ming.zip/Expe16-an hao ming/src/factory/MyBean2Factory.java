package factory;

import bean.Bean1;

public class MyBean2Factory {
	public static Bean1 createBean(){
		return new Bean1();
	}
}
