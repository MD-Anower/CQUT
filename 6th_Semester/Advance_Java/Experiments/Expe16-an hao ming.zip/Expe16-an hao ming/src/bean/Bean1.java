package bean;

public class Bean1 {

}
