import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;

import entity.Course;
import entity.Student;


public class Many2ManyDemoTest {
	@Test
	public void test1(){
		
	    Session session =HibernateSessionFactory.getSession();
	    Transaction t = session.beginTransaction();

	    Student s1 = new Student();
	    s1.setNo("1012");
	    s1.setName("Lili");
	    Student s2 = new Student();
	    s2.setNo("1013");
	    s2.setName("John");

	    Course c1 = new Course();
	    c1.setName("Java");
	    Course c2 = new Course();
	    c2.setName("C");
	    
	    s1.getCourse().add(c1);
	    s1.getCourse().add(c2);
		s2.getCourse().add(c1);
		s2.getCourse().add(c2);
	
		session.save(c1);
		session.save(c2);
		session.save(s1);
		session.save(s2);

	    t.commit();
	    session.close();

	}
}
