import org.hibernate.Session;
import org.hibernate.Transaction;
import org.junit.Test;
import entity.Class;
import entity.Student;
public class One2ManyTest {
	@Test
	public void test1(){
		Session session = HibernateSessionFactory.getSession();
		Transaction t = session.beginTransaction();
		
		Class c = new Class();
		c.setName("6201703L1");
		
		Student s1=new Student();
		s1.setNo("1005");
		s1.setName("asa");
		
		Student s2=new Student();
		s2.setNo("1006");
		s2.setName("asif");
		
		s1.setMyClass(c);
		s2.setMyClass(c);
		
		c.getStudents().add(s1);
		c.getStudents().add(s2);
		
		session.save(c);
		session.save(s1);
		session.save(s2);
		
		t.commit();
		session.close();
		
	}

}
